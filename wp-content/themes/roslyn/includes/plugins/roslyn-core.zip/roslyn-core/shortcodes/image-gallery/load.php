<?php

include_once ROSLYN_CORE_SHORTCODES_PATH . '/image-gallery/functions.php';
include_once ROSLYN_CORE_SHORTCODES_PATH . '/image-gallery/image-gallery.php';