<?php if ( $query_result->max_num_pages > 1 ) { ?>
	<div class="eltdf-spinner eltdf-rotate-line eltdf-hide-spinner"></div>
<?php }