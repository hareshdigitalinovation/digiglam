<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/masonry-layout/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/masonry-layout/masonry-layout.php';