<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout2/widget/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout2/widget/layout2.php';