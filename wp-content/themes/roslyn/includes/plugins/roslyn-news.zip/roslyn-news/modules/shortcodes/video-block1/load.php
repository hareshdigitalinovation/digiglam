<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/video-block1/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/video-block1/video-block1.php';