<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout4/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout4/layout4.php';