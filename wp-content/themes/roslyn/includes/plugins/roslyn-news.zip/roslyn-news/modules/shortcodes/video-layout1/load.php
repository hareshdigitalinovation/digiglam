<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/video-layout1/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/video-layout1/video-layout1.php';