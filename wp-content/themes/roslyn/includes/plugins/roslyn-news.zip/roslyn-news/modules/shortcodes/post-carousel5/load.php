<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/post-carousel5/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/post-carousel5/post-carousel5.php';