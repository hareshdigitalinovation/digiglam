<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/post-carousel6/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/post-carousel6/post-carousel6.php';