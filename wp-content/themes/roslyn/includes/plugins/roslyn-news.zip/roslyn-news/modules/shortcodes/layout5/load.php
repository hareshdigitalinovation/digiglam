<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout5/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout5/layout5.php';