<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout1/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout1/layout1.php';