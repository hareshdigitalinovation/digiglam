<div class="eltdf-news-post-top-holder">
	<?php echo roslyn_news_get_blog_part( 'parts/image', 'templates', '', array() ); ?>
	<div class="eltdf-npt-info-bottom">
		<div class="eltdf-grid">
			<div class="eltdf-npt-info-bottom-inner">
				<?php echo roslyn_news_get_blog_part( 'parts/post-info/hot-trending', 'templates', '', array(
					'display_hot_trending_icons' => 'yes',
					'display_hot_trending_text'  => true
				) ); ?>
			</div>
		</div>
	</div>
</div>