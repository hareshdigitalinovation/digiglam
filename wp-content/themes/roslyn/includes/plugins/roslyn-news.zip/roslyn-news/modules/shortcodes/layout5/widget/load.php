<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout5/widget/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout5/widget/layout5.php';