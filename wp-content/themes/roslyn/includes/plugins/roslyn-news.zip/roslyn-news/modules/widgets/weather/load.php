<?php

include_once ROSLYN_NEWS_WIDGETS_PATH . '/weather/functions.php';
include_once ROSLYN_NEWS_WIDGETS_PATH . '/weather/weather.php';