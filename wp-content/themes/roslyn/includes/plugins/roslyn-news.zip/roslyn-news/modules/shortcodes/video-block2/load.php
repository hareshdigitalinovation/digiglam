<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/video-block2/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/video-block2/video-block2.php';