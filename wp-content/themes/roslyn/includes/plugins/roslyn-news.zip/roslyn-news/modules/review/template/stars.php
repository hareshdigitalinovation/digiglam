<div class="eltdf-news-review-stars-holder">
	<div class="eltdf-news-review-stars-all">
		<?php for ( $i = 1; $i <= 5; $i ++ ) { ?>
			<span class="eltdf-nr-star fa fa-star"></span>
		<?php } ?>
	</div>
	<div class="eltdf-news-review-stars" <?php roslyn_elated_inline_style( $style ) ?>>
		<?php for ( $i = 1; $i <= 5; $i ++ ) { ?>
			<span class="eltdf-nr-star fa fa-star"></span>
		<?php } ?>
	</div>
</div>