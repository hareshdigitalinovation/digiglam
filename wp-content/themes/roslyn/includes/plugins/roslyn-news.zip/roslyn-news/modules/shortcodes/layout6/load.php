<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout6/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout6/layout6.php';