<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/post-carousel1/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/post-carousel1/post-carousel1.php';