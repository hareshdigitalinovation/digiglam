<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/post-carousel2/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/post-carousel2/post-carousel2.php';