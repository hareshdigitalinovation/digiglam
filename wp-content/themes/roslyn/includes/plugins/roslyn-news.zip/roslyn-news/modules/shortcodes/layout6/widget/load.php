<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout6/widget/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout6/widget/layout6.php';