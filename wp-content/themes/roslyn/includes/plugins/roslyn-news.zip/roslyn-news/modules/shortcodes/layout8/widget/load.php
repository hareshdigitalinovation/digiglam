<?php

include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout8/widget/functions.php';
include_once ROSLYN_NEWS_SHORTCODES_PATH . '/layout8/widget/layout8.php';